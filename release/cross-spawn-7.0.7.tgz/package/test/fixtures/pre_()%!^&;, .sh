#!/bin/bash

echo special
