@echo off
echo special
