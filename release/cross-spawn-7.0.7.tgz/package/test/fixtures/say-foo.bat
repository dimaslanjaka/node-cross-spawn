@echo off
echo foo
